## Doggieradicator
Uma extensão do Google que permite que você substitua os comentários do G1 em fotos aleatórias de cachorros.

### Version 1.1
Download: https://chrome.google.com/webstore/detail/doggieradicator/afnmoghknejnchdbaccokjilkaljjfde

### About
O Doggieradicator é uma extensão do Google Chrome gratuita que serve para você que está cansado de visualizar os comentários do G1 e se decepcionar toda vez que acaba lendo o que está sendo escrito ali. 

Infelizmente a maioria dos comentários são racistas, preconceituosos, machistas, incitação ao ódio e, é claro, spam também. 

Então em vez de ficar lendo esses comentários tão tristes, que tal ficar olhando para lindas fotos aleatórias de cachorrinhos? Que tal deixar o seu dia mais feliz? :) 
